#' Trains a simple deep NN on the MNIST dataset.
#'
#' Gets to 98.40% test accuracy after 20 epochs (there is *a lot* of margin for
#' parameter tuning).
#'

library(keras)

# Hyperparameter flags ---------------------------------------------------

FLAGS <- flags(
  flag_numeric("dropout1", 0.4),
  flag_numeric("dropout2", 0.3)
)

# Data Preparation ---------------------------------------------------

# Load data
data <- read.table('epil-seizure.csv', header = T, stringsAsFactors = F, sep=',')

# Split data into to explanatory (exp) and response (res)
exp <- data.matrix(data[,2:179])
res <- data[,180]

# Split dataset into test and training
epi_x_train <- exp[1:10000,]
epi_y_train.cat <- res[1:10000]
epi_y_train <- to_categorical(epi_y_train.cat)[,2:6]

epi_x_test <- exp[10001:nrow(exp),]
epi_y_test.cat <- res[10001:nrow(exp)]
epi_y_test <- to_categorical(epi_y_test.cat)[,2:6]

# Define Model --------------------------------------------------------------

# generate model
model = keras_model_sequential() 
model %>%
  layer_dense(units = flags$l1units, activation = 'relu', input_shape = c(ncol(exp))) %>% 
  #layer_dropout(rate = 0.8) %>% 
  layer_dense(units = flags$l2units, activation = 'relu') %>%
  #layer_dense(units = 40, activation = 'relu') %>%
  layer_dense(units = 5, activation = 'softmax')

# compile the model
model %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = 'adam',
  #optimizer = sgd,
  metrics = c('accuracy')
)


# Training & Evaluation ----------------------------------------------------

history <- model %>% fit(
  epi_x_train, epi_y_train, 
  epochs = 20, 
  validation_split = 0.2,
  #callbacks = callback_tensorboard("logs/run_c"),
  verbose = 1
)

plot(history)

score <- model %>% evaluate(epi_x_test, epi_y_test, verbose = 0)

cat('Test loss:', score$loss, '\n')
cat('Test accuracy:', score$acc, '\n')
